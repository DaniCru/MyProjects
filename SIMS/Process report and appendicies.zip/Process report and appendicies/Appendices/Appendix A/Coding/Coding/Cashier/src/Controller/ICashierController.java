package Controller;

public interface ICashierController {

}
