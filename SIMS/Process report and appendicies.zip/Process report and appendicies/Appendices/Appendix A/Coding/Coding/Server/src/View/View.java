package View;

/**
 * The server's view.
 * @author
 *
 */
public class View {
	
	/**
	 * The method that displays a message on the screen;
	 * @param msg message to be displayed;
	 */
	public void print(String msg) {
		System.out.println(msg);
	}
}